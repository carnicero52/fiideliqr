import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  Business,
  AdminUser,
  Customer,
  Stamp,
  Reward,
  Redemption,
  LoyaltyConfig,
  NotificationConfig,
  ActionLog,
  AdminSection,
  SettingsTab,
  CurrentPanel,
  ConfirmModalConfig,
  Toast,
} from '@/types';

// Datos iniciales de demo
const initialBusiness: Business = {
  id: 'biz_001',
  name: 'Café El Aroma',
  logoUrl: '',
  primaryColor: '#6366f1',
  secondaryColor: '#8b5cf6',
  description: 'El mejor café de la ciudad, con granos seleccionados y ambiente acogedor.',
  address: 'Calle Principal 123, Centro',
  phone: '+58 412-1234567',
  email: 'contacto@cafearoma.com',
  phonePrefix: '+58',
};

const initialLoyaltyConfig: LoyaltyConfig = {
  programName: 'Club El Aroma',
  stampsForReward: 10,
  stampType: 'visits',
  stampExpiration: null,
};

const initialNotificationConfig: NotificationConfig = {
  welcomeMessage: '¡Bienvenido a {businessName}! Gracias por unirte a nuestro programa de fidelización.',
  stampAddedMessage: '¡Sello añadido! Tienes {currentStamps} de {requiredStamps} sellos.',
  nearRewardMessage: '¡Casi llegas! Solo te falta 1 sello para tu próxima recompensa.',
  rewardEarnedMessage: '¡Felicidades! Has ganado una recompensa. Canjéala cuando quieras.',
  promoMessage: '¡Promoción especial! Ven hoy y obtén el doble de sellos.',
  pushEnabled: true,
  smsEnabled: false,
  emailEnabled: true,
};

const initialRewards: Reward[] = [
  {
    id: 'reward_001',
    businessId: 'biz_001',
    name: 'Café Gratis',
    description: 'Un delicioso café espresso o americano completamente gratis.',
    requiredStamps: 10,
    isActive: true,
    imageUrl: '',
    validFrom: '2024-01-01',
    validUntil: '2025-12-31',
    promoCode: 'CAFE10',
  },
  {
    id: 'reward_002',
    businessId: 'biz_001',
    name: 'Postre del Día',
    description: 'Elige cualquier postre de nuestra vitrina sin costo.',
    requiredStamps: 15,
    isActive: true,
    imageUrl: '',
    validFrom: '2024-01-01',
    validUntil: '2025-12-31',
    promoCode: 'POSTRE15',
  },
  {
    id: 'reward_003',
    businessId: 'biz_001',
    name: 'Desayuno VIP',
    description: 'Desayuno completo con café, jugo, pan y huevos.',
    requiredStamps: 20,
    isActive: true,
    imageUrl: '',
    validFrom: '2024-01-01',
    validUntil: '2025-12-31',
    promoCode: 'VIP20',
  },
];

const initialCustomers: Customer[] = [
  {
    id: 'cust_001',
    businessId: 'biz_001',
    phone: '+58 412-1111111',
    name: 'María González',
    email: 'maria@email.com',
    qrCode: 'QR_MARIA_001',
    totalStamps: 8,
    redeemedRewards: 2,
    createdAt: '2024-01-15T10:00:00Z',
    lastVisit: '2024-02-05T14:30:00Z',
    isActive: true,
  },
  {
    id: 'cust_002',
    businessId: 'biz_001',
    phone: '+58 412-2222222',
    name: 'Carlos Rodríguez',
    email: 'carlos@email.com',
    qrCode: 'QR_CARLOS_002',
    totalStamps: 15,
    redeemedRewards: 1,
    createdAt: '2024-01-20T11:00:00Z',
    lastVisit: '2024-02-04T09:15:00Z',
    isActive: true,
  },
  {
    id: 'cust_003',
    businessId: 'biz_001',
    phone: '+58 412-3333333',
    name: 'Ana Martínez',
    email: 'ana@email.com',
    qrCode: 'QR_ANA_003',
    totalStamps: 3,
    redeemedRewards: 0,
    createdAt: '2024-02-01T16:00:00Z',
    lastVisit: '2024-02-06T18:45:00Z',
    isActive: true,
  },
  {
    id: 'cust_004',
    businessId: 'biz_001',
    phone: '+58 412-4444444',
    name: 'Pedro López',
    email: 'pedro@email.com',
    qrCode: 'QR_PEDRO_004',
    totalStamps: 12,
    redeemedRewards: 3,
    createdAt: '2023-12-10T08:30:00Z',
    lastVisit: '2024-01-28T12:00:00Z',
    isActive: false,
  },
];

const initialStamps: Stamp[] = [
  { id: 'stamp_001', customerId: 'cust_001', businessId: 'biz_001', source: 'scan', createdAt: '2024-02-05T14:30:00Z' },
  { id: 'stamp_002', customerId: 'cust_001', businessId: 'biz_001', source: 'manual', createdAt: '2024-02-03T10:00:00Z' },
  { id: 'stamp_003', customerId: 'cust_002', businessId: 'biz_001', source: 'scan', createdAt: '2024-02-04T09:15:00Z' },
  { id: 'stamp_004', customerId: 'cust_003', businessId: 'biz_001', source: 'scan', createdAt: '2024-02-06T18:45:00Z' },
];

const initialRedemptions: Redemption[] = [
  { id: 'red_001', customerId: 'cust_001', rewardId: 'reward_001', usedAt: '2024-01-25T15:00:00Z', code: 'RED_CAFE001' },
  { id: 'red_002', customerId: 'cust_001', rewardId: 'reward_001', usedAt: '2024-02-01T11:30:00Z', code: 'RED_CAFE002' },
  { id: 'red_003', customerId: 'cust_002', rewardId: 'reward_002', usedAt: '2024-01-30T14:00:00Z', code: 'RED_POSTRE001' },
];

const initialActionLogs: ActionLog[] = [
  { id: 'log_001', action: 'Sistema iniciado', details: 'Datos de demo cargados correctamente', performedBy: 'system', timestamp: '2024-02-06T00:00:00Z', type: 'info' },
];

// Estado del store
interface AppState {
  // Navegación
  currentPanel: CurrentPanel;
  adminSection: AdminSection;
  settingsTab: SettingsTab;
  darkMode: boolean;

  // Autenticación
  isAdminAuthenticated: boolean;
  isClientAuthenticated: boolean;
  currentAdmin: AdminUser | null;
  currentCustomer: Customer | null;

  // Datos
  business: Business;
  loyaltyConfig: LoyaltyConfig;
  notificationConfig: NotificationConfig;
  rewards: Reward[];
  customers: Customer[];
  stamps: Stamp[];
  redemptions: Redemption[];
  actionLogs: ActionLog[];

  // UI
  showConfirmModal: boolean;
  confirmModalConfig: ConfirmModalConfig | null;
  toasts: Toast[];

  // Acciones de navegación
  setCurrentPanel: (panel: CurrentPanel) => void;
  setAdminSection: (section: AdminSection) => void;
  setSettingsTab: (tab: SettingsTab) => void;
  toggleDarkMode: () => void;

  // Acciones de autenticación
  loginAdmin: (email: string, password: string, provider: 'google' | 'email') => void;
  logoutAdmin: () => void;
  loginClient: (phone: string, name?: string) => boolean;
  logoutClient: () => void;

  // Acciones de negocio
  updateBusiness: (data: Partial<Business>) => void;
  updateLoyaltyConfig: (data: Partial<LoyaltyConfig>) => void;
  updateNotificationConfig: (data: Partial<NotificationConfig>) => void;

  // Acciones de clientes
  addCustomer: (data: Omit<Customer, 'id' | 'qrCode' | 'totalStamps' | 'redeemedRewards' | 'createdAt' | 'lastVisit'>) => Customer;
  updateCustomer: (id: string, data: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  addStampToCustomer: (customerId: string, source: 'scan' | 'manual', notes?: string) => void;
  removeStampFromCustomer: (customerId: string) => void;

  // Acciones de recompensas
  addReward: (data: Omit<Reward, 'id' | 'promoCode'>) => void;
  updateReward: (id: string, data: Partial<Reward>) => void;
  deleteReward: (id: string) => void;
  redeemReward: (customerId: string, rewardId: string) => Redemption | null;

  // Controles admin
  resetProgram: (type: 'stamps' | 'all') => void;
  deleteInactiveCustomers: () => void;
  wipeAllData: () => void;
  addActionLog: (action: string, details: string, type: ActionLog['type']) => void;

  // Modal
  showConfirm: (config: ConfirmModalConfig) => void;
  hideConfirm: () => void;

  // Toast
  showToast: (message: string, type: Toast['type']) => void;
  removeToast: (id: string) => void;

  // Helpers
  getCustomerByQrCode: (qrCode: string) => Customer | undefined;
  getCustomerStamps: (customerId: string) => number;
  getAvailableRewards: (customerId: string) => Reward[];
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Estado inicial
      currentPanel: 'admin',
      adminSection: 'dashboard',
      settingsTab: 'business',
      darkMode: false,
      isAdminAuthenticated: false,
      isClientAuthenticated: false,
      currentAdmin: null,
      currentCustomer: null,
      business: initialBusiness,
      loyaltyConfig: initialLoyaltyConfig,
      notificationConfig: initialNotificationConfig,
      rewards: initialRewards,
      customers: initialCustomers,
      stamps: initialStamps,
      redemptions: initialRedemptions,
      actionLogs: initialActionLogs,
      showConfirmModal: false,
      confirmModalConfig: null,
      toasts: [],

      // Navegación
      setCurrentPanel: (panel) => set({ currentPanel: panel }),
      setAdminSection: (section) => set({ adminSection: section }),
      setSettingsTab: (tab) => set({ settingsTab: tab }),
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),

      // Autenticación
      loginAdmin: (email, _password, provider) => {
        const admin: AdminUser = {
          id: 'admin_001',
          businessId: 'biz_001',
          email,
          name: email.split('@')[0],
          role: 'admin',
          authProvider: provider,
        };
        set({ isAdminAuthenticated: true, currentAdmin: admin });
        get().addActionLog('Inicio de sesión', `Admin ${email} inició sesión`, 'info');
      },
      logoutAdmin: () => {
        set({ isAdminAuthenticated: false, currentAdmin: null });
      },
      loginClient: (phone, name) => {
        const { customers, business } = get();
        const existingCustomer = customers.find((c) => c.phone === phone);

        if (existingCustomer) {
          set({
            isClientAuthenticated: true,
            currentCustomer: existingCustomer,
          });
          get().addActionLog('Cliente inició sesión', `${existingCustomer.name} - ${phone}`, 'info');
          return true;
        }

        if (name) {
          const newCustomer = get().addCustomer({
            businessId: business.id,
            phone,
            name,
            email: '',
            isActive: true,
          });
          set({
            isClientAuthenticated: true,
            currentCustomer: newCustomer,
          });
          return true;
        }

        return false;
      },
      logoutClient: () => {
        set({ isClientAuthenticated: false, currentCustomer: null });
      },

      // Negocio
      updateBusiness: (data) => {
        set((state) => ({ business: { ...state.business, ...data } }));
        get().addActionLog('Negocio actualizado', 'Datos del negocio modificados', 'info');
      },
      updateLoyaltyConfig: (data) => {
        set((state) => ({ loyaltyConfig: { ...state.loyaltyConfig, ...data } }));
        get().addActionLog('Configuración de fidelidad actualizada', '', 'info');
      },
      updateNotificationConfig: (data) => {
        set((state) => ({ notificationConfig: { ...state.notificationConfig, ...data } }));
        get().addActionLog('Notificaciones actualizadas', '', 'info');
      },

      // Clientes
      addCustomer: (data) => {
        const newCustomer: Customer = {
          ...data,
          id: `cust_${Date.now()}`,
          qrCode: `QR_${data.name.replace(/\s+/g, '_').toUpperCase()}_${Date.now()}`,
          totalStamps: 0,
          redeemedRewards: 0,
          createdAt: new Date().toISOString(),
          lastVisit: new Date().toISOString(),
        };
        set((state) => ({ customers: [...state.customers, newCustomer] }));
        get().addActionLog('Nuevo cliente', `${newCustomer.name} - ${newCustomer.phone}`, 'info');
        return newCustomer;
      },
      updateCustomer: (id, data) => {
        set((state) => ({
          customers: state.customers.map((c) => (c.id === id ? { ...c, ...data } : c)),
        }));
        get().addActionLog('Cliente actualizado', `ID: ${id}`, 'info');
      },
      deleteCustomer: (id) => {
        set((state) => ({
          customers: state.customers.filter((c) => c.id !== id),
          stamps: state.stamps.filter((s) => s.customerId !== id),
        }));
        get().addActionLog('Cliente eliminado', `ID: ${id}`, 'danger');
      },
      addStampToCustomer: (customerId, source, notes) => {
        const newStamp: Stamp = {
          id: `stamp_${Date.now()}`,
          customerId,
          businessId: 'biz_001',
          source,
          createdAt: new Date().toISOString(),
          notes,
        };
        set((state) => ({
          stamps: [...state.stamps, newStamp],
          customers: state.customers.map((c) =>
            c.id === customerId
              ? { ...c, totalStamps: c.totalStamps + 1, lastVisit: new Date().toISOString() }
              : c
          ),
        }));
        get().addActionLog('Sello añadido', `Cliente: ${customerId}, Fuente: ${source}`, 'info');
      },
      removeStampFromCustomer: (customerId) => {
        set((state) => {
          const customerStamps = state.stamps.filter((s) => s.customerId === customerId);
          if (customerStamps.length === 0) return state;
          const lastStamp = customerStamps[customerStamps.length - 1];
          return {
            stamps: state.stamps.filter((s) => s.id !== lastStamp.id),
            customers: state.customers.map((c) =>
              c.id === customerId ? { ...c, totalStamps: Math.max(0, c.totalStamps - 1) } : c
            ),
          };
        });
        get().addActionLog('Sello removido', `Cliente: ${customerId}`, 'warning');
      },

      // Recompensas
      addReward: (data) => {
        const newReward: Reward = {
          ...data,
          id: `reward_${Date.now()}`,
          promoCode: `PROMO${Math.floor(Math.random() * 10000)}`,
        };
        set((state) => ({ rewards: [...state.rewards, newReward] }));
        get().addActionLog('Nueva recompensa', newReward.name, 'info');
      },
      updateReward: (id, data) => {
        set((state) => ({
          rewards: state.rewards.map((r) => (r.id === id ? { ...r, ...data } : r)),
        }));
        get().addActionLog('Recompensa actualizada', `ID: ${id}`, 'info');
      },
      deleteReward: (id) => {
        set((state) => ({ rewards: state.rewards.filter((r) => r.id !== id) }));
        get().addActionLog('Recompensa eliminada', `ID: ${id}`, 'danger');
      },
      redeemReward: (customerId, rewardId) => {
        const { customers, rewards } = get();
        const customer = customers.find((c) => c.id === customerId);
        const reward = rewards.find((r) => r.id === rewardId);

        if (!customer || !reward) return null;
        if (customer.totalStamps < reward.requiredStamps) return null;

        const newRedemption: Redemption = {
          id: `red_${Date.now()}`,
          customerId,
          rewardId,
          usedAt: new Date().toISOString(),
          code: `RED_${reward.promoCode}_${Date.now()}`,
        };

        set((state) => ({
          redemptions: [...state.redemptions, newRedemption],
          customers: state.customers.map((c) =>
            c.id === customerId
              ? {
                  ...c,
                  totalStamps: c.totalStamps - reward.requiredStamps,
                  redeemedRewards: c.redeemedRewards + 1,
                }
              : c
          ),
        }));

        get().addActionLog('Recompensa canjeada', `${reward.name} - Cliente: ${customer.name}`, 'info');
        return newRedemption;
      },

      // Controles admin
      resetProgram: (type) => {
        if (type === 'stamps') {
          set((state) => ({
            stamps: [],
            customers: state.customers.map((c) => ({ ...c, totalStamps: 0 })),
          }));
          get().addActionLog('Programa reiniciado', 'Sello reseteados a 0', 'warning');
        } else {
          set({
            stamps: [],
            redemptions: [],
            customers: [],
          });
          get().addActionLog('Programa reiniciado', 'Todos los datos eliminados', 'danger');
        }
      },
      deleteInactiveCustomers: () => {
        set((state) => ({
          customers: state.customers.filter((c) => c.isActive),
        }));
        get().addActionLog('Clientes inactivos eliminados', '', 'warning');
      },
      wipeAllData: () => {
        set({
          customers: [],
          stamps: [],
          redemptions: [],
          rewards: [],
          actionLogs: [],
        });
        get().addActionLog('Todos los datos borrados', '', 'danger');
      },
      addActionLog: (action, details, type) => {
        const newLog: ActionLog = {
          id: `log_${Date.now()}`,
          action,
          details,
          performedBy: get().currentAdmin?.email || 'system',
          timestamp: new Date().toISOString(),
          type,
        };
        set((state) => ({ actionLogs: [newLog, ...state.actionLogs].slice(0, 100) }));
      },

      // Modal
      showConfirm: (config) => {
        set({ showConfirmModal: true, confirmModalConfig: config });
      },
      hideConfirm: () => {
        set({ showConfirmModal: false, confirmModalConfig: null });
      },

      // Toast
      showToast: (message, type) => {
        const id = `toast_${Date.now()}`;
        set((state) => ({ toasts: [...state.toasts, { id, message, type }] }));
        setTimeout(() => {
          get().removeToast(id);
        }, 3000);
      },
      removeToast: (id) => {
        set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
      },

      // Helpers
      getCustomerByQrCode: (qrCode) => {
        return get().customers.find((c) => c.qrCode === qrCode);
      },
      getCustomerStamps: (customerId) => {
        return get().stamps.filter((s) => s.customerId === customerId).length;
      },
      getAvailableRewards: (customerId) => {
        const customer = get().customers.find((c) => c.id === customerId);
        if (!customer) return [];
        return get().rewards.filter(
          (r) => r.isActive && customer.totalStamps >= r.requiredStamps
        );
      },
    }),
    {
      name: 'fideliqr-storage',
      partialize: (state) => ({
        business: state.business,
        loyaltyConfig: state.loyaltyConfig,
        notificationConfig: state.notificationConfig,
        rewards: state.rewards,
        customers: state.customers,
        stamps: state.stamps,
        redemptions: state.redemptions,
        actionLogs: state.actionLogs,
        darkMode: state.darkMode,
      }),
    }
  )
);
