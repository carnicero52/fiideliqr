import { useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  BookOpen,
  QrCode,
  Users,
  Gift,
  HelpCircle,
  Mail,
  ExternalLink,
  MessageCircle,
} from 'lucide-react';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  icon: React.ElementType;
}

const faqs: FAQItem[] = [
  {
    id: 'getting-started',
    question: '¿Cómo empezar con FideliQR?',
    answer:
      'Para comenzar, configura los datos de tu negocio en la sección de Configuración. Luego, crea tus recompensas en la sección de Recompensas. Una vez listo, tus clientes pueden registrarse con su número de teléfono y comenzar a acumular sellos.',
    icon: BookOpen,
  },
  {
    id: 'scan-qr',
    question: '¿Cómo escanear códigos QR?',
    answer:
      'Desde el Dashboard, haz clic en el botón "Escanear QR del Cliente". Apunta la cámara al código QR del cliente. El sistema reconocerá automáticamente al cliente y podrás añadir un sello con un solo clic.',
    icon: QrCode,
  },
  {
    id: 'manage-customers',
    question: '¿Cómo gestionar clientes?',
    answer:
      'En la sección Clientes puedes ver todos tus clientes, añadir o quitar sellos manualmente, editar sus datos, ver sus códigos QR y canjear recompensas. También puedes exportar la lista a CSV.',
    icon: Users,
  },
  {
    id: 'configure-rewards',
    question: '¿Cómo configurar recompensas?',
    answer:
      'Ve a la sección Recompensas y haz clic en "Nueva Recompensa". Define el nombre, descripción, cantidad de sellos necesarios y sube una imagen. Puedes establecer fechas de validez y códigos promocionales.',
    icon: Gift,
  },
  {
    id: 'notifications',
    question: '¿Cómo funcionan las notificaciones?',
    answer:
      'Las notificaciones se envían automáticamente a los clientes cuando se añaden sellos o canjean recompensas. Puedes personalizar los mensajes en la sección Notificaciones y elegir los canales (Push, SMS, Email).',
    icon: MessageCircle,
  },
  {
    id: 'reset-data',
    question: '¿Cómo reiniciar los datos?',
    answer:
      'En Configuración > Zona de Peligro encontrarás opciones para reiniciar solo los sellos (manteniendo clientes) o borrar todos los datos. Ten cuidado, estas acciones no se pueden deshacer.',
    icon: BookOpen,
  },
];

export function Help() {
  const [openItem, setOpenItem] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center py-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl mb-4">
          <HelpCircle className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Centro de Ayuda</h2>
        <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-md mx-auto">
          Encuentra respuestas a las preguntas más frecuentes sobre el uso de FideliQR
        </p>
      </div>

      {/* FAQs */}
      <div className="space-y-4">
        {faqs.map((faq) => {
          const Icon = faq.icon;
          const isOpen = openItem === faq.id;

          return (
            <div
              key={faq.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden"
            >
              <button
                onClick={() => setOpenItem(isOpen ? null : faq.id)}
                className="w-full flex items-center gap-4 p-4 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                </div>
                <span className="flex-1 font-medium text-gray-900 dark:text-white">
                  {faq.question}
                </span>
                {isOpen ? (
                  <ChevronUp className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                )}
              </button>
              {isOpen && (
                <div className="px-4 pb-4 pl-[72px]">
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Contact Section */}
      <div className="bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          ¿Necesitas más ayuda?
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <a
            href="mailto:soporte@fideliqr.com"
            className="flex items-center gap-3 p-4 bg-white/10 backdrop-blur rounded-lg hover:bg-white/20 transition-colors"
          >
            <Mail className="w-5 h-5" />
            <div>
              <p className="font-medium">Email de Soporte</p>
              <p className="text-sm text-white/70">soporte@fideliqr.com</p>
            </div>
          </a>
          <a
            href="#"
            className="flex items-center gap-3 p-4 bg-white/10 backdrop-blur rounded-lg hover:bg-white/20 transition-colors"
          >
            <BookOpen className="w-5 h-5" />
            <div>
              <p className="font-medium">Documentación</p>
              <p className="text-sm text-white/70">Ver guía completa</p>
            </div>
            <ExternalLink className="w-4 h-4 ml-auto" />
          </a>
        </div>
      </div>

      {/* Tips */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-amber-800 dark:text-amber-400 mb-4">
          Consejos Rápidos
        </h3>
        <ul className="space-y-3">
          <li className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-amber-200 dark:bg-amber-800 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs font-bold text-amber-700 dark:text-amber-300">1</span>
            </div>
            <p className="text-amber-700 dark:text-amber-300">
              <strong>Mantén actualizadas las recompensas</strong> - Ofrece variedad para mantener
              el interés de tus clientes.
            </p>
          </li>
          <li className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-amber-200 dark:bg-amber-800 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs font-bold text-amber-700 dark:text-amber-300">2</span>
            </div>
            <p className="text-amber-700 dark:text-amber-300">
              <strong>Personaliza los mensajes</strong> - Usa el nombre de tu negocio para hacer
              las notificaciones más cercanas.
            </p>
          </li>
          <li className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-amber-200 dark:bg-amber-800 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs font-bold text-amber-700 dark:text-amber-300">3</span>
            </div>
            <p className="text-amber-700 dark:text-amber-300">
              <strong>Revisa el Dashboard</strong> - Monitorea la actividad y identifica a tus
              clientes más fieles.
            </p>
          </li>
        </ul>
      </div>
    </div>
  );
}
