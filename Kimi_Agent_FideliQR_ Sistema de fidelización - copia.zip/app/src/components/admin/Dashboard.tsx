import { useState } from 'react';
import {
  Users,
  Stamp,
  Gift,
  TrendingUp,
  Camera,
  Clock,
  User,
} from 'lucide-react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';
import { QRScanner } from './QRScanner';

function formatRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

  if (diffInHours < 1) return 'Hace minutos';
  if (diffInHours < 24) return `Hace ${diffInHours}h`;
  if (diffInHours < 48) return 'Ayer';
  return `Hace ${Math.floor(diffInHours / 24)} días`;
}

export function Dashboard() {
  const [showScanner, setShowScanner] = useState(false);
  const { customers, stamps, redemptions, rewards, business } = useStore();

  // Métricas
  const activeCustomers = customers.filter((c) => c.isActive).length;
  const totalStamps = stamps.length;
  const totalRedemptions = redemptions.length;
  const conversionRate =
    customers.length > 0
      ? Math.round((customers.filter((c) => c.redeemedRewards > 0).length / customers.length) * 100)
      : 0;

  // Actividad reciente (últimos 10 sellos o canjes)
  const recentActivity = [
    ...stamps.map((s) => ({ type: 'stamp' as const, date: s.createdAt, data: s })),
    ...redemptions.map((r) => ({ type: 'redemption' as const, date: r.usedAt, data: r })),
  ]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 10);

  // Top clientes
  const topCustomers = [...customers]
    .sort((a, b) => b.totalStamps - a.totalStamps)
    .slice(0, 5);

  const metrics = [
    {
      label: 'Clientes Activos',
      value: activeCustomers,
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      label: 'Sellos Totales',
      value: totalStamps,
      icon: Stamp,
      color: 'bg-indigo-500',
    },
    {
      label: 'Canjes Realizados',
      value: totalRedemptions,
      icon: Gift,
      color: 'bg-violet-500',
    },
    {
      label: 'Tasa de Conversión',
      value: `${conversionRate}%`,
      icon: TrendingUp,
      color: 'bg-green-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div
              key={metric.label}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{metric.label}</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                    {metric.value}
                  </p>
                </div>
                <div className={cn('w-12 h-12 rounded-lg flex items-center justify-center', metric.color)}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Scan QR Button */}
      <button
        onClick={() => setShowScanner(true)}
        className="w-full py-4 px-6 rounded-xl text-white font-semibold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-3"
        style={{
          background: `linear-gradient(135deg, ${business.primaryColor}, ${business.secondaryColor})`,
        }}
      >
        <Camera className="w-6 h-6" />
        Escanear QR del Cliente
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-500" />
              Actividad Reciente
            </h3>
          </div>
          <div className="p-4 space-y-3 max-h-[400px] overflow-y-auto">
            {recentActivity.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                No hay actividad reciente
              </p>
            ) : (
              recentActivity.map((activity, index) => {
                const isStamp = activity.type === 'stamp';
                const customer = customers.find((c) =>
                  isStamp
                    ? c.id === (activity.data as typeof stamps[0]).customerId
                    : c.id === (activity.data as typeof redemptions[0]).customerId
                );
                const reward = !isStamp
                  ? rewards.find((r) => r.id === (activity.data as typeof redemptions[0]).rewardId)
                  : null;

                return (
                  <div
                    key={`${activity.type}-${index}`}
                    className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-700/50"
                  >
                    <div
                      className={cn(
                        'w-10 h-10 rounded-full flex items-center justify-center',
                        isStamp
                          ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400'
                          : 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400'
                      )}
                    >
                      {isStamp ? <Stamp className="w-5 h-5" /> : <Gift className="w-5 h-5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                        {isStamp
                          ? `Sello añadido a ${customer?.name || 'Cliente'}`
                          : `Canje: ${reward?.name || 'Recompensa'}`}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {formatRelativeTime(activity.date)}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Top Customers */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <User className="w-5 h-5 text-indigo-500" />
              Top Clientes
            </h3>
          </div>
          <div className="p-4 space-y-3">
            {topCustomers.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                No hay clientes registrados
              </p>
            ) : (
              topCustomers.map((customer) => (
                <div
                  key={customer.id}
                  className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-700/50"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white text-sm font-semibold">
                    {customer.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {customer.name}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{customer.phone}</p>
                  </div>
                  <div className="flex items-center gap-1 px-2 py-1 bg-indigo-100 dark:bg-indigo-900/30 rounded-full">
                    <Stamp className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                    <span className="text-xs font-medium text-indigo-600 dark:text-indigo-400">
                      {customer.totalStamps}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* QR Scanner Modal */}
      {showScanner && <QRScanner onClose={() => setShowScanner(false)} />}
    </div>
  );
}
