import { useEffect, useRef, useState } from 'react';
import { X, Check, RefreshCw, Camera } from 'lucide-react';
import { Html5Qrcode } from 'html5-qrcode';
import { useStore } from '@/store';

interface QRScannerProps {
  onClose: () => void;
}

type ScannerState = 'scanning' | 'found' | 'error';

export function QRScanner({ onClose }: QRScannerProps) {
  const [state, setState] = useState<ScannerState>('scanning');
  const [scannedCustomer, setScannedCustomer] = useState<ReturnType<typeof useStore.getState>['customers'][0] | undefined>(undefined);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = 'qr-scanner-container';
  const { getCustomerByQrCode, addStampToCustomer, loyaltyConfig, showToast } = useStore();

  useEffect(() => {
    const initScanner = async () => {
      try {
        scannerRef.current = new Html5Qrcode(scannerContainerId);
        await scannerRef.current.start(
          { facingMode: 'environment' },
          {
            fps: 10,
            qrbox: { width: 250, height: 250 },
          },
          (decodedText) => {
            handleScan(decodedText);
          },
          () => {
            // Error de escaneo (ignorar)
          }
        );
      } catch (error) {
        console.error('Error initializing scanner:', error);
        setState('error');
      }
    };

    initScanner();

    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, []);

  const handleScan = (qrCode: string) => {
    const customer = getCustomerByQrCode(qrCode);
    if (customer) {
      setScannedCustomer(customer);
      setState('found');
      if (scannerRef.current) {
        scannerRef.current.pause();
      }
    } else {
      setState('error');
    }
  };

  const handleAddStamp = () => {
    if (scannedCustomer) {
      addStampToCustomer(scannedCustomer.id, 'scan');
      showToast(`Sello añadido a ${scannedCustomer.name}`, 'success');
      handleScanAnother();
    }
  };

  const handleScanAnother = () => {
    setScannedCustomer(undefined);
    setState('scanning');
    if (scannerRef.current) {
      scannerRef.current.resume();
    }
  };

  const progress = scannedCustomer
    ? Math.min(100, (scannedCustomer.totalStamps / loyaltyConfig.stampsForReward) * 100)
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            {state === 'scanning' && 'Escanear QR'}
            {state === 'found' && 'Cliente Encontrado'}
            {state === 'error' && 'QR No Válido'}
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {state === 'scanning' && (
            <div className="space-y-4">
              <div
                id={scannerContainerId}
                className="w-full aspect-square rounded-xl overflow-hidden bg-black"
              />
              <p className="text-center text-gray-500 dark:text-gray-400">
                Apunta la cámara al código QR del cliente
              </p>
            </div>
          )}

          {state === 'found' && scannedCustomer && (
            <div className="space-y-6">
              {/* Customer Info */}
              <div className="text-center">
                <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white text-2xl font-bold mb-3">
                  {scannedCustomer.name.charAt(0).toUpperCase()}
                </div>
                <h4 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {scannedCustomer.name}
                </h4>
                <p className="text-gray-500 dark:text-gray-400">{scannedCustomer.phone}</p>
              </div>

              {/* Progress */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Progreso</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {scannedCustomer.totalStamps} / {loyaltyConfig.stampsForReward} sellos
                  </span>
                </div>
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-violet-600 transition-all"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <button
                  onClick={handleAddStamp}
                  className="w-full py-3 px-4 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                >
                  <Check className="w-5 h-5" />
                  Añadir Sello
                </button>
                <div className="flex gap-3">
                  <button
                    onClick={handleScanAnother}
                    className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Escanear otro
                  </button>
                  <button
                    onClick={onClose}
                    className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            </div>
          )}

          {state === 'error' && (
            <div className="text-center space-y-6">
              <div className="w-20 h-20 mx-auto rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                <X className="w-10 h-10 text-red-500" />
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Código QR no válido
                </h4>
                <p className="text-gray-500 dark:text-gray-400">
                  Este código no corresponde a ningún cliente registrado.
                </p>
              </div>
              <button
                onClick={handleScanAnother}
                className="w-full py-3 px-4 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Camera className="w-5 h-5" />
                Intentar de nuevo
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
