import { useState, useRef } from 'react';
import {
  QrCode,
  Gift,
  History,
  User,
  LogOut,
  Download,
  Share2,
  Menu,
  X,
  Stamp,
  Check,
  Moon,
  Sun,
  Edit2,
  Save,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';

type ClientTab = 'card' | 'rewards' | 'history' | 'profile';

export function ClientPanel() {
  const [activeTab, setActiveTab] = useState<ClientTab>('card');
  const [showMenu, setShowMenu] = useState(false);
  const { currentCustomer, business, logoutClient, darkMode, toggleDarkMode } = useStore();

  if (!currentCustomer) return null;

  const tabs: { id: ClientTab; label: string; icon: React.ElementType }[] = [
    { id: 'card', label: 'Mi Tarjeta', icon: QrCode },
    { id: 'rewards', label: 'Recompensas', icon: Gift },
    { id: 'history', label: 'Historial', icon: History },
    { id: 'profile', label: 'Perfil', icon: User },
  ];

  return (
    <div className={cn('min-h-screen bg-gray-50 dark:bg-gray-950', darkMode ? 'dark' : '')}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 sticky top-0 z-20">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{
                background: `linear-gradient(135deg, ${business.primaryColor}, ${business.secondaryColor})`,
              }}
            >
              <QrCode className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-gray-900 dark:text-white">FideliQR</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">{business.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleDarkMode}
              className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            >
              {showMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {showMenu && (
          <div className="border-t border-gray-200 dark:border-gray-800 p-4 space-y-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setShowMenu(false);
                  }}
                  className={cn(
                    'w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                    activeTab === tab.id
                      ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400'
                      : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
                  )}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
            <button
              onClick={logoutClient}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              Cerrar sesión
            </button>
          </div>
        )}
      </header>

      {/* Bottom Navigation (Mobile) */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 z-20 lg:hidden">
        <div className="flex justify-around">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'flex flex-col items-center gap-1 py-3 px-4 transition-colors',
                  activeTab === tab.id
                    ? 'text-indigo-600 dark:text-indigo-400'
                    : 'text-gray-500 dark:text-gray-400'
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Main Content */}
      <main className="p-4 pb-24 lg:pb-4 max-w-2xl mx-auto">
        {activeTab === 'card' && <CardTab />}
        {activeTab === 'rewards' && <RewardsTab />}
        {activeTab === 'history' && <HistoryTab />}
        {activeTab === 'profile' && <ProfileTab />}
      </main>
    </div>
  );
}

function CardTab() {
  const { currentCustomer, business, loyaltyConfig } = useStore();
  const qrRef = useRef<HTMLDivElement>(null);

  if (!currentCustomer) return null;

  const progress = Math.min(
    100,
    (currentCustomer.totalStamps / loyaltyConfig.stampsForReward) * 100
  );
  const stampsNeeded = Math.max(0, loyaltyConfig.stampsForReward - currentCustomer.totalStamps);

  const handleDownloadQR = () => {
    const svg = qrRef.current?.querySelector('svg');
    if (!svg) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const svgData = new XMLSerializer().serializeToString(svg);
    const img = new Image();
    img.onload = () => {
      canvas.width = 400;
      canvas.height = 500;

      // Background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Header gradient
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
      gradient.addColorStop(0, business.primaryColor);
      gradient.addColorStop(1, business.secondaryColor);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, 80);

      // Business name
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(business.name, canvas.width / 2, 45);

      // QR Code
      const qrSize = 280;
      const qrX = (canvas.width - qrSize) / 2;
      ctx.drawImage(img, qrX, 110, qrSize, qrSize);

      // Border around QR
      ctx.strokeStyle = '#e5e7eb';
      ctx.lineWidth = 2;
      ctx.strokeRect(qrX - 10, 100, qrSize + 20, qrSize + 20);

      // Customer info
      ctx.fillStyle = '#1f2937';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText(currentCustomer.name, canvas.width / 2, 430);

      ctx.fillStyle = '#6b7280';
      ctx.font = '16px sans-serif';
      ctx.fillText(currentCustomer.phone, canvas.width / 2, 455);

      // Footer
      ctx.fillStyle = '#9ca3af';
      ctx.font = '12px sans-serif';
      ctx.fillText('FideliQR - Tu tarjeta de fidelidad digital', canvas.width / 2, 485);

      const link = document.createElement('a');
      link.download = `mi-qr-${currentCustomer.name.replace(/\s+/g, '-').toLowerCase()}.png`;
      link.href = canvas.toDataURL();
      link.click();
    };
    img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Mi tarjeta ${business.name}`,
          text: `¡Únete a ${business.name} y acumula sellos! Mi código: ${currentCustomer.qrCode}`,
        });
      } catch {
        // User cancelled
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Loyalty Card */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700 p-6">
        <div className="text-center">
          {/* QR Code */}
          <div ref={qrRef} className="inline-block p-4 bg-white rounded-xl shadow-inner">
            <QRCodeSVG
              value={currentCustomer.qrCode}
              size={200}
              level="H"
              includeMargin
              bgColor="#ffffff"
              fgColor="#000000"
            />
          </div>

          {/* Customer Info */}
          <h2 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">
            {currentCustomer.name}
          </h2>
          <p className="text-gray-500 dark:text-gray-400">{currentCustomer.phone}</p>

          {/* Actions */}
          <div className="flex gap-3 mt-6">
            <button
              onClick={handleDownloadQR}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Descargar QR
            </button>
            <button
              onClick={handleShare}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <Share2 className="w-4 h-4" />
              Compartir
            </button>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900 dark:text-white">Tu Progreso</h3>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {currentCustomer.totalStamps} / {loyaltyConfig.stampsForReward} sellos
          </span>
        </div>

        {/* Progress Bar */}
        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mb-4">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${progress}%`,
              background: `linear-gradient(90deg, ${business.primaryColor}, ${business.secondaryColor})`,
            }}
          />
        </div>

        {stampsNeeded > 0 ? (
          <p className="text-center text-gray-600 dark:text-gray-400">
            Te faltan <span className="font-semibold text-indigo-600">{stampsNeeded}</span> sellos
            para tu próxima recompensa
          </p>
        ) : (
          <p className="text-center text-green-600 font-medium">
            ¡Felicidades! Puedes canjear una recompensa
          </p>
        )}

        {/* Stamps Grid */}
        <div className="mt-6">
          <div className="flex flex-wrap justify-center gap-2">
            {Array.from({ length: loyaltyConfig.stampsForReward }).map((_, i) => {
              const isFilled = i < currentCustomer.totalStamps;
              return (
                <div
                  key={i}
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                    isFilled
                      ? 'bg-indigo-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-400'
                  )}
                >
                  {isFilled ? <Check className="w-5 h-5" /> : <Stamp className="w-4 h-4" />}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function RewardsTab() {
  const { currentCustomer, rewards, redeemReward, showToast } = useStore();

  if (!currentCustomer) return null;

  const availableRewards = rewards.filter(
    (r) => r.isActive && currentCustomer.totalStamps >= r.requiredStamps
  );
  const lockedRewards = rewards.filter(
    (r) => r.isActive && currentCustomer.totalStamps < r.requiredStamps
  );

  const handleRedeem = (reward: (typeof rewards)[0]) => {
    const result = redeemReward(currentCustomer.id, reward.id);
    if (result) {
      showToast(`¡${reward.name} canjeado! Código: ${result.code}`, 'success');
    }
  };

  return (
    <div className="space-y-6">
      {/* Available Rewards */}
      <div>
        <h3 className="font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Check className="w-5 h-5 text-green-500" />
          Disponibles para canjear
        </h3>
        {availableRewards.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400 text-center py-8 bg-white dark:bg-gray-800 rounded-xl">
            Sigue acumulando sellos para desbloquear recompensas
          </p>
        ) : (
          <div className="space-y-3">
            {availableRewards.map((reward) => (
              <div
                key={reward.id}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-green-200 dark:border-green-800 p-4"
              >
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                    {reward.imageUrl ? (
                      <img
                        src={reward.imageUrl}
                        alt={reward.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    ) : (
                      <Gift className="w-8 h-8 text-gray-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 dark:text-white">{reward.name}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2">
                      {reward.description}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                        {reward.requiredStamps} sellos
                      </span>
                      <button
                        onClick={() => handleRedeem(reward)}
                        className="px-3 py-1.5 bg-green-500 hover:bg-green-600 text-white text-sm rounded-lg transition-colors"
                      >
                        Canjear
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Locked Rewards */}
      {lockedRewards.length > 0 && (
        <div>
          <h3 className="font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <Stamp className="w-5 h-5 text-gray-400" />
            Próximas recompensas
          </h3>
          <div className="space-y-3">
            {lockedRewards.map((reward) => {
              const stampsNeeded = reward.requiredStamps - currentCustomer.totalStamps;
              return (
                <div
                  key={reward.id}
                  className="bg-gray-100 dark:bg-gray-800/50 rounded-xl p-4 opacity-70"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 rounded-lg bg-gray-200 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                      {reward.imageUrl ? (
                        <img
                          src={reward.imageUrl}
                          alt={reward.name}
                          className="w-full h-full object-cover rounded-lg opacity-50"
                        />
                      ) : (
                        <Gift className="w-8 h-8 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-700 dark:text-gray-300">
                        {reward.name}
                      </h4>
                      <p className="text-sm text-gray-500 dark:text-gray-500 line-clamp-2">
                        {reward.description}
                      </p>
                      <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
                        Te faltan {stampsNeeded} sellos
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function HistoryTab() {
  const { currentCustomer, stamps, redemptions, rewards } = useStore();

  if (!currentCustomer) return null;

  // Combinar sellos y canjes
  const history = [
    ...stamps
      .filter((s) => s.customerId === currentCustomer.id)
      .map((s) => ({ type: 'stamp' as const, date: s.createdAt, data: s })),
    ...redemptions
      .filter((r) => r.customerId === currentCustomer.id)
      .map((r) => ({ type: 'redemption' as const, date: r.usedAt, data: r })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-gray-900 dark:text-white">Historial de Actividad</h3>

      {history.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400 text-center py-8 bg-white dark:bg-gray-800 rounded-xl">
          No hay actividad registrada
        </p>
      ) : (
        <div className="space-y-3">
          {history.map((item, index) => {
            const isStamp = item.type === 'stamp';
            const reward = !isStamp
              ? rewards.find((r) => r.id === (item.data as typeof redemptions[0]).rewardId)
              : null;

            return (
              <div
                key={`${item.type}-${index}`}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 flex items-center gap-4"
              >
                <div
                  className={cn(
                    'w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0',
                    isStamp
                      ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400'
                      : 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400'
                  )}
                >
                  {isStamp ? <Stamp className="w-6 h-6" /> : <Gift className="w-6 h-6" />}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900 dark:text-white">
                    {isStamp
                      ? `Sello obtenido (${(item.data as typeof stamps[0]).source === 'scan' ? 'escaneo' : 'manual'})`
                      : `Canjeaste: ${reward?.name || 'Recompensa'}`}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {new Date(item.date).toLocaleDateString('es-ES', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
                {!isStamp && (
                  <span className="text-xs font-mono text-gray-400">{(item.data as typeof redemptions[0]).code}</span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ProfileTab() {
  const { currentCustomer, updateCustomer, showToast } = useStore();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: currentCustomer?.name || '',
    email: currentCustomer?.email || '',
  });

  if (!currentCustomer) return null;

  const handleSave = () => {
    updateCustomer(currentCustomer.id, formData);
    setIsEditing(false);
    showToast('Perfil actualizado', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Avatar */}
      <div className="text-center">
        <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white text-3xl font-bold">
          {currentCustomer.name.charAt(0).toUpperCase()}
        </div>
        <h3 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">
          {currentCustomer.name}
        </h3>
        <p className="text-gray-500 dark:text-gray-400">Miembro desde {new Date(currentCustomer.createdAt).toLocaleDateString()}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 text-center">
          <p className="text-2xl font-bold text-indigo-600">{currentCustomer.totalStamps}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Sellos totales</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 text-center">
          <p className="text-2xl font-bold text-green-600">{currentCustomer.redeemedRewards}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Canjes realizados</p>
        </div>
      </div>

      {/* Form */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-semibold text-gray-900 dark:text-white">Información Personal</h4>
          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
            >
              <Edit2 className="w-4 h-4" />
            </button>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Nombre
          </label>
          {isEditing ? (
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
          ) : (
            <p className="text-gray-900 dark:text-white">{currentCustomer.name}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Email
          </label>
          {isEditing ? (
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
          ) : (
            <p className="text-gray-900 dark:text-white">{currentCustomer.email || '-'}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Teléfono
          </label>
          <p className="text-gray-900 dark:text-white">{currentCustomer.phone}</p>
        </div>

        {isEditing && (
          <div className="flex gap-3 pt-4">
            <button
              onClick={() => {
                setIsEditing(false);
                setFormData({ name: currentCustomer.name, email: currentCustomer.email });
              }}
              className="flex-1 py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleSave}
              className="flex-1 py-2 px-4 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              Guardar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
