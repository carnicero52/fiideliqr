import { useEffect } from 'react';
import { useStore } from '@/store';
import { AdminLogin } from '@/components/auth/AdminLogin';
import { ClientLogin } from '@/components/auth/ClientLogin';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Dashboard } from '@/components/admin/Dashboard';
import { Customers } from '@/components/admin/Customers';
import { Rewards } from '@/components/admin/Rewards';
import { Notifications } from '@/components/admin/Notifications';
import { Settings } from '@/components/admin/Settings';
import { Help } from '@/components/admin/Help';
import { ClientPanel } from '@/components/client/ClientPanel';
import { ToastContainer } from '@/components/shared/Toast';
import { ConfirmModal } from '@/components/shared/ConfirmModal';
import { cn } from '@/utils/cn';

function App() {
  const {
    currentPanel,
    adminSection,
    isAdminAuthenticated,
    isClientAuthenticated,
    darkMode,
  } = useStore();

  // Apply dark mode to document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Render Admin Panel
  if (currentPanel === 'admin') {
    if (!isAdminAuthenticated) {
      return (
        <>
          <AdminLogin />
          <ToastContainer />
          <ConfirmModal />
        </>
      );
    }

    return (
      <div className={cn(darkMode && 'dark')}>
        <AdminLayout>
          {adminSection === 'dashboard' && <Dashboard />}
          {adminSection === 'customers' && <Customers />}
          {adminSection === 'rewards' && <Rewards />}
          {adminSection === 'notifications' && <Notifications />}
          {adminSection === 'settings' && <Settings />}
          {adminSection === 'help' && <Help />}
        </AdminLayout>
        <ToastContainer />
        <ConfirmModal />
      </div>
    );
  }

  // Render Client Panel
  if (!isClientAuthenticated) {
    return (
      <>
        <ClientLogin />
        <ToastContainer />
        <ConfirmModal />
      </>
    );
  }

  return (
    <>
      <ClientPanel />
      <ToastContainer />
      <ConfirmModal />
    </>
  );
}

export default App;
