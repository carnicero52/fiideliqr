import { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';

const typeStyles = {
  warning: {
    icon: 'text-amber-500 bg-amber-100',
    button: 'bg-amber-500 hover:bg-amber-600',
  },
  danger: {
    icon: 'text-red-500 bg-red-100',
    button: 'bg-red-500 hover:bg-red-600',
  },
  info: {
    icon: 'text-blue-500 bg-blue-100',
    button: 'bg-blue-500 hover:bg-blue-600',
  },
};

export function ConfirmModal() {
  const { showConfirmModal, confirmModalConfig, hideConfirm } = useStore();
  const [typedText, setTypedText] = useState('');
  const [password, setPassword] = useState('');

  if (!showConfirmModal || !confirmModalConfig) return null;

  const { title, message, type, requireTyping, requirePassword, onConfirm } = confirmModalConfig;
  const styles = typeStyles[type];

  const isConfirmDisabled =
    (requireTyping && typedText !== requireTyping) ||
    (requirePassword && password !== 'admin123');

  const handleConfirm = () => {
    if (isConfirmDisabled) return;
    onConfirm();
    hideConfirm();
    setTypedText('');
    setPassword('');
  };

  const handleCancel = () => {
    hideConfirm();
    setTypedText('');
    setPassword('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
        <div className="p-6">
          <div className="flex items-start gap-4">
            <div className={cn('p-3 rounded-full flex-shrink-0', styles.icon)}>
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">{message}</p>

              {requireTyping && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Escribe "{requireTyping}" para confirmar
                  </label>
                  <input
                    type="text"
                    value={typedText}
                    onChange={(e) => setTypedText(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                    placeholder={requireTyping}
                  />
                </div>
              )}

              {requirePassword && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Contraseña de administrador
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                    placeholder="••••••••"
                  />
                  <p className="text-xs text-gray-500 mt-1">Contraseña demo: admin123</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex gap-3 px-6 pb-6">
          <button
            onClick={handleCancel}
            className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleConfirm}
            disabled={isConfirmDisabled}
            className={cn(
              'flex-1 px-4 py-2 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed',
              styles.button
            )}
          >
            Confirmar
          </button>
        </div>
      </div>
    </div>
  );
}
