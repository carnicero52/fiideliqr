import { useState, useRef } from 'react';
import {
  Store,
  Gift,
  Bell,
  AlertTriangle,
  Trash2,
  RefreshCw,
  UserX,
  Save,
  Check,
  Upload,
  X,
  Palette,
  Phone,
  MapPin,
  Mail,
  FileText,
  Clock,
  Type,
  Hash,
} from 'lucide-react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';
import type { SettingsTab } from '@/types';

const phonePrefixes = [
  { code: '+58', country: 'Venezuela' },
  { code: '+52', country: 'México' },
  { code: '+34', country: 'España' },
  { code: '+1', country: 'USA' },
  { code: '+57', country: 'Colombia' },
  { code: '+54', country: 'Argentina' },
  { code: '+56', country: 'Chile' },
  { code: '+51', country: 'Perú' },
  { code: '+593', country: 'Ecuador' },
  { code: '+502', country: 'Guatemala' },
  { code: '+503', country: 'El Salvador' },
  { code: '+507', country: 'Panamá' },
  { code: '+55', country: 'Brasil' },
];

const colorPresets = [
  { primary: '#6366f1', secondary: '#8b5cf6', name: 'Indigo-Violeta' },
  { primary: '#3b82f6', secondary: '#06b6d4', name: 'Azul-Cyan' },
  { primary: '#10b981', secondary: '#84cc16', name: 'Esmeralda-Lima' },
  { primary: '#f59e0b', secondary: '#ef4444', name: 'Ámbar-Rojo' },
  { primary: '#ec4899', secondary: '#a855f7', name: 'Rosa-Púrpura' },
  { primary: '#1f2937', secondary: '#4b5563', name: 'Gris Oscuro' },
];

export function Settings() {
  const { settingsTab, setSettingsTab } = useStore();

  const tabs: { id: SettingsTab; label: string; icon: React.ElementType }[] = [
    { id: 'business', label: 'Negocio', icon: Store },
    { id: 'loyalty', label: 'Programa de Fidelidad', icon: Gift },
    { id: 'notifications', label: 'Notificaciones', icon: Bell },
    { id: 'danger', label: 'Zona de Peligro', icon: AlertTriangle },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Configuración</h2>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-gray-200 dark:border-gray-700 pb-4">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = settingsTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSettingsTab(tab.id)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-lg transition-colors',
                isActive
                  ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
              )}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      {settingsTab === 'business' && <BusinessSettings />}
      {settingsTab === 'loyalty' && <LoyaltySettings />}
      {settingsTab === 'notifications' && <NotificationsSettings />}
      {settingsTab === 'danger' && <DangerZone />}
    </div>
  );
}

function BusinessSettings() {
  const { business, updateBusiness, showToast } = useStore();
  const [formData, setFormData] = useState(business);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('La imagen debe ser menor a 2MB');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData({ ...formData, logoUrl: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    updateBusiness(formData);
    setIsSaving(false);
    showToast('Configuración guardada', 'success');
  };

  const hasChanges = JSON.stringify(formData) !== JSON.stringify(business);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 space-y-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
        <Store className="w-5 h-5 text-indigo-500" />
        Información del Negocio
      </h3>

      {/* Logo */}
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Logo
        </label>
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-700">
            {formData.logoUrl ? (
              <img src={formData.logoUrl} alt="Logo" className="w-full h-full object-cover" />
            ) : (
              <Store className="w-8 h-8 text-gray-400" />
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Subir
            </button>
            {formData.logoUrl && (
              <button
                onClick={() => setFormData({ ...formData, logoUrl: '' })}
                className="px-3 py-2 border border-red-300 dark:border-red-600 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Eliminar
              </button>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleLogoUpload}
            className="hidden"
          />
        </div>
      </div>

      {/* Colors */}
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          <Palette className="w-4 h-4 inline mr-1" />
          Colores del Negocio
        </label>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-4">
          {colorPresets.map((preset) => (
            <button
              key={preset.name}
              onClick={() =>
                setFormData({
                  ...formData,
                  primaryColor: preset.primary,
                  secondaryColor: preset.secondary,
                })
              }
              className={cn(
                'p-2 rounded-lg border-2 transition-all',
                formData.primaryColor === preset.primary
                  ? 'border-indigo-500'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
              )}
            >
              <div className="flex gap-1 mb-1">
                <div
                  className="w-6 h-6 rounded"
                  style={{ backgroundColor: preset.primary }}
                />
                <div
                  className="w-6 h-6 rounded"
                  style={{ backgroundColor: preset.secondary }}
                />
              </div>
              <span className="text-xs text-gray-600 dark:text-gray-400">{preset.name}</span>
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Color Primario</label>
            <div className="flex gap-2">
              <input
                type="color"
                value={formData.primaryColor}
                onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                className="w-10 h-10 rounded border border-gray-300 dark:border-gray-600"
              />
              <input
                type="text"
                value={formData.primaryColor}
                onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white font-mono text-sm"
              />
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Color Secundario</label>
            <div className="flex gap-2">
              <input
                type="color"
                value={formData.secondaryColor}
                onChange={(e) => setFormData({ ...formData, secondaryColor: e.target.value })}
                className="w-10 h-10 rounded border border-gray-300 dark:border-gray-600"
              />
              <input
                type="text"
                value={formData.secondaryColor}
                onChange={(e) => setFormData({ ...formData, secondaryColor: e.target.value })}
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white font-mono text-sm"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Basic Info */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <Type className="w-4 h-4 inline mr-1" />
            Nombre del Negocio
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <FileText className="w-4 h-4 inline mr-1" />
            Descripción
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white resize-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <MapPin className="w-4 h-4 inline mr-1" />
            Dirección
          </label>
          <input
            type="text"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              <Phone className="w-4 h-4 inline mr-1" />
              Teléfono de Contacto
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              <Mail className="w-4 h-4 inline mr-1" />
              Email de Contacto
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <Phone className="w-4 h-4 inline mr-1" />
            Prefijo Telefónico para Clientes
          </label>
          <select
            value={formData.phonePrefix}
            onChange={(e) => setFormData({ ...formData, phonePrefix: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          >
            {phonePrefixes.map((p) => (
              <option key={p.code} value={p.code}>
                {p.code} {p.country}
              </option>
            ))}
            <option value="custom">Otro (personalizado)</option>
          </select>
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        disabled={!hasChanges || isSaving}
        className={cn(
          'w-full py-3 px-4 rounded-lg font-semibold transition-all flex items-center justify-center gap-2',
          hasChanges
            ? 'bg-indigo-500 hover:bg-indigo-600 text-white'
            : 'bg-green-500 text-white cursor-default'
        )}
      >
        {isSaving ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Guardando...
          </>
        ) : hasChanges ? (
          <>
            <Save className="w-5 h-5" />
            Guardar Cambios
          </>
        ) : (
          <>
            <Check className="w-5 h-5" />
            ¡Guardado!
          </>
        )}
      </button>
    </div>
  );
}

function LoyaltySettings() {
  const { loyaltyConfig, updateLoyaltyConfig, showToast } = useStore();
  const [formData, setFormData] = useState(loyaltyConfig);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    updateLoyaltyConfig(formData);
    setIsSaving(false);
    showToast('Configuración guardada', 'success');
  };

  const hasChanges = JSON.stringify(formData) !== JSON.stringify(loyaltyConfig);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 space-y-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
        <Gift className="w-5 h-5 text-indigo-500" />
        Programa de Fidelidad
      </h3>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <Type className="w-4 h-4 inline mr-1" />
            Nombre del Programa
          </label>
          <input
            type="text"
            value={formData.programName}
            onChange={(e) => setFormData({ ...formData, programName: e.target.value })}
            placeholder="Ej: Club de Fidelidad"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <Hash className="w-4 h-4 inline mr-1" />
            Sellos para Recompensa
          </label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min={1}
              max={20}
              value={formData.stampsForReward}
              onChange={(e) =>
                setFormData({ ...formData, stampsForReward: parseInt(e.target.value) })
              }
              className="flex-1"
            />
            <span className="w-12 text-center font-semibold text-gray-900 dark:text-white">
              {formData.stampsForReward}
            </span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Tipo de Sellos
          </label>
          <select
            value={formData.stampType}
            onChange={(e) =>
              setFormData({ ...formData, stampType: e.target.value as typeof formData.stampType })
            }
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          >
            <option value="visits">Visitas</option>
            <option value="purchases">Compras</option>
            <option value="points">Puntos</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            <Clock className="w-4 h-4 inline mr-1" />
            Caducidad de Sellos
          </label>
          <div className="flex items-center gap-4">
            <input
              type="checkbox"
              id="noExpiration"
              checked={formData.stampExpiration === null}
              onChange={(e) =>
                setFormData({ ...formData, stampExpiration: e.target.checked ? null : 365 })
              }
              className="w-4 h-4 text-indigo-500 rounded"
            />
            <label htmlFor="noExpiration" className="text-sm text-gray-700 dark:text-gray-300">
              Sin caducidad
            </label>
          </div>
          {formData.stampExpiration !== null && (
            <div className="mt-2">
              <input
                type="number"
                min={1}
                value={formData.stampExpiration}
                onChange={(e) =>
                  setFormData({ ...formData, stampExpiration: parseInt(e.target.value) || 1 })
                }
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              />
              <p className="text-xs text-gray-500 mt-1">Días antes de que expiren los sellos</p>
            </div>
          )}
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        disabled={!hasChanges || isSaving}
        className={cn(
          'w-full py-3 px-4 rounded-lg font-semibold transition-all flex items-center justify-center gap-2',
          hasChanges
            ? 'bg-indigo-500 hover:bg-indigo-600 text-white'
            : 'bg-green-500 text-white cursor-default'
        )}
      >
        {isSaving ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Guardando...
          </>
        ) : hasChanges ? (
          <>
            <Save className="w-5 h-5" />
            Guardar Cambios
          </>
        ) : (
          <>
            <Check className="w-5 h-5" />
            ¡Guardado!
          </>
        )}
      </button>
    </div>
  );
}

function NotificationsSettings() {
  const { showToast } = useStore();
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    setIsSaving(false);
    showToast('Configuración guardada', 'success');
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 space-y-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
        <Bell className="w-5 h-5 text-indigo-500" />
        Configuración de Notificaciones
      </h3>

      <p className="text-gray-500 dark:text-gray-400">
        Para configurar las plantillas de mensajes, ve a la sección{' '}
        <button
          onClick={() => useStore.getState().setAdminSection('notifications')}
          className="text-indigo-600 hover:underline"
        >
          Notificaciones
        </button>
      </p>

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="w-full py-3 px-4 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 bg-green-500 text-white"
      >
        {isSaving ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Guardando...
          </>
        ) : (
          <>
            <Check className="w-5 h-5" />
            ¡Guardado!
          </>
        )}
      </button>
    </div>
  );
}

function DangerZone() {
  const { resetProgram, deleteInactiveCustomers, wipeAllData, showConfirm, showToast, actionLogs } =
    useStore();

  return (
    <div className="space-y-6">
      {/* Warning Banner */}
      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4 flex items-start gap-3">
        <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-red-700 dark:text-red-400">Zona de Peligro</h3>
          <p className="text-sm text-red-600 dark:text-red-300">
            Las acciones en esta sección son irreversibles. Usa con precaución.
          </p>
        </div>
      </div>

      {/* Reset Program */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <RefreshCw className="w-5 h-5 text-amber-500" />
          Reiniciar Programa
        </h3>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() =>
              showConfirm({
                title: 'Reiniciar Sellos',
                message: '¿Estás seguro? Todos los sellos se pondrán en 0, pero los clientes se mantendrán.',
                type: 'warning',
                onConfirm: () => {
                  resetProgram('stamps');
                  showToast('Sellos reiniciados', 'success');
                },
              })
            }
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition-colors"
          >
            Reiniciar solo sellos
          </button>
          <button
            onClick={() =>
              showConfirm({
                title: 'Reiniciar Todo',
                message: '¿Estás seguro? Se eliminarán todos los sellos, canjes y clientes.',
                type: 'danger',
                onConfirm: () => {
                  resetProgram('all');
                  showToast('Programa reiniciado completamente', 'success');
                },
              })
            }
            className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
          >
            Reiniciar todo
          </button>
        </div>
      </div>

      {/* Delete Inactive */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <UserX className="w-5 h-5 text-amber-500" />
          Eliminar Clientes
        </h3>
        <button
          onClick={() =>
            showConfirm({
              title: 'Eliminar Clientes Inactivos',
              message: '¿Estás seguro? Se eliminarán todos los clientes marcados como inactivos.',
              type: 'warning',
              onConfirm: () => {
                deleteInactiveCustomers();
                showToast('Clientes inactivos eliminados', 'success');
              },
            })
          }
          className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition-colors"
        >
          Eliminar clientes inactivos
        </button>
      </div>

      {/* Wipe All Data */}
      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-red-700 dark:text-red-400 mb-4 flex items-center gap-2">
          <Trash2 className="w-5 h-5" />
          Borrar Todos los Datos
        </h3>
        <p className="text-sm text-red-600 dark:text-red-300 mb-4">
          Esta acción eliminará permanentemente todos los datos: clientes, sellos, canjes,
          recompensas y registros.
        </p>
        <button
          onClick={() =>
            showConfirm({
              title: 'Borrar Todos los Datos',
              message: '¡ATENCIÓN! Esta acción es irreversible. Todos los datos serán eliminados.',
              type: 'danger',
              requireTyping: 'BORRAR TODO',
              requirePassword: true,
              onConfirm: () => {
                wipeAllData();
                showToast('Todos los datos han sido eliminados', 'success');
              },
            })
          }
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
        >
          Borrar Todo
        </button>
      </div>

      {/* Action Logs */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Historial de Acciones
        </h3>
        <div className="max-h-[300px] overflow-y-auto space-y-2">
          {actionLogs.length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400 text-center py-4">
              No hay registros de acciones
            </p>
          ) : (
            actionLogs.slice(0, 20).map((log) => (
              <div
                key={log.id}
                className={cn(
                  'p-3 rounded-lg text-sm',
                  log.type === 'info' && 'bg-blue-50 dark:bg-blue-900/20',
                  log.type === 'warning' && 'bg-amber-50 dark:bg-amber-900/20',
                  log.type === 'danger' && 'bg-red-50 dark:bg-red-900/20'
                )}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={cn(
                      'font-medium',
                      log.type === 'info' && 'text-blue-700 dark:text-blue-400',
                      log.type === 'warning' && 'text-amber-700 dark:text-amber-400',
                      log.type === 'danger' && 'text-red-700 dark:text-red-400'
                    )}
                  >
                    {log.action}
                  </span>
                  <span className="text-xs text-gray-400">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>
                {log.details && (
                  <p className="text-gray-600 dark:text-gray-400 mt-1">{log.details}</p>
                )}
                <p className="text-xs text-gray-400 mt-1">Por: {log.performedBy}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
