import { useState } from 'react';
import { Bell, MessageSquare, Smartphone, Mail, Check, Info } from 'lucide-react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';

export function Notifications() {
  const { notificationConfig, updateNotificationConfig, business, showToast } = useStore();
  const [localConfig, setLocalConfig] = useState(notificationConfig);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    updateNotificationConfig(localConfig);
    setIsSaving(false);
    showToast('Configuración guardada', 'success');
  };

  const hasChanges = JSON.stringify(localConfig) !== JSON.stringify(notificationConfig);

  const channels = [
    {
      key: 'pushEnabled' as const,
      label: 'Push Notifications',
      description: 'Notificaciones en tiempo real dentro de la app',
      icon: Bell,
    },
    {
      key: 'smsEnabled' as const,
      label: 'SMS',
      description: 'Mensajes de texto a los teléfonos de los clientes',
      icon: Smartphone,
    },
    {
      key: 'emailEnabled' as const,
      label: 'Email',
      description: 'Correos electrónicos a los clientes',
      icon: Mail,
    },
  ];

  const templates = [
    {
      key: 'welcomeMessage' as const,
      label: 'Mensaje de Bienvenida',
      description: 'Enviado cuando un cliente se registra',
      variables: ['{businessName}'],
      placeholder: '¡Bienvenido a {businessName}! Gracias por unirte...',
    },
    {
      key: 'stampAddedMessage' as const,
      label: 'Sello Añadido',
      description: 'Notificación cuando se añade un sello',
      variables: ['{currentStamps}', '{requiredStamps}'],
      placeholder: '¡Sello añadido! Tienes {currentStamps} de {requiredStamps} sellos.',
    },
    {
      key: 'nearRewardMessage' as const,
      label: 'Cerca de Recompensa',
      description: 'Cuando el cliente está a 1 sello de una recompensa',
      variables: [],
      placeholder: '¡Casi llegas! Solo te falta 1 sello para tu próxima recompensa.',
    },
    {
      key: 'rewardEarnedMessage' as const,
      label: 'Recompensa Obtenida',
      description: 'Cuando el cliente gana una recompensa',
      variables: [],
      placeholder: '¡Felicidades! Has ganado una recompensa. Canjéala cuando quieras.',
    },
    {
      key: 'promoMessage' as const,
      label: 'Promociones Especiales',
      description: 'Mensaje para promociones y ofertas especiales',
      variables: [],
      placeholder: '¡Promoción especial! Ven hoy y obtén el doble de sellos.',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Notificaciones</h2>
        <button
          onClick={handleSave}
          disabled={!hasChanges || isSaving}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg transition-all',
            hasChanges
              ? 'bg-indigo-500 hover:bg-indigo-600 text-white'
              : 'bg-green-500 text-white cursor-default'
          )}
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Guardando...
            </>
          ) : hasChanges ? (
            <>
              <Check className="w-4 h-4" />
              Guardar Cambios
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              ¡Guardado!
            </>
          )}
        </button>
      </div>

      {/* Channels Section */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Bell className="w-5 h-5 text-indigo-500" />
          Canales de Notificación
        </h3>
        <div className="space-y-4">
          {channels.map((channel) => {
            const Icon = channel.icon;
            const isEnabled = localConfig[channel.key];
            return (
              <div
                key={channel.key}
                className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      'w-10 h-10 rounded-lg flex items-center justify-center transition-colors',
                      isEnabled
                        ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-400'
                    )}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{channel.label}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{channel.description}</p>
                  </div>
                </div>
                <button
                  onClick={() =>
                    setLocalConfig({ ...localConfig, [channel.key]: !isEnabled })
                  }
                  className={cn(
                    'w-12 h-6 rounded-full transition-colors relative',
                    isEnabled ? 'bg-indigo-500' : 'bg-gray-300 dark:bg-gray-600'
                  )}
                >
                  <span
                    className={cn(
                      'absolute top-1 w-4 h-4 bg-white rounded-full transition-transform',
                      isEnabled ? 'left-7' : 'left-1'
                    )}
                  />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Templates Section */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-indigo-500" />
          Plantillas de Mensajes
        </h3>
        <div className="space-y-6">
          {templates.map((template) => (
            <div key={template.key}>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {template.label}
              </label>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                {template.description}
              </p>
              <textarea
                value={localConfig[template.key]}
                onChange={(e) =>
                  setLocalConfig({ ...localConfig, [template.key]: e.target.value })
                }
                placeholder={template.placeholder}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white resize-none"
              />
              {template.variables.length > 0 && (
                <div className="flex items-center gap-2 mt-2">
                  <Info className="w-3 h-3 text-gray-400" />
                  <span className="text-xs text-gray-500">Variables: </span>
                  {template.variables.map((v) => (
                    <span
                      key={v}
                      className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded text-xs font-mono"
                    >
                      {v}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Preview Section */}
      <div className="bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-4">Vista Previa</h3>
        <div className="space-y-3">
          <div className="bg-white/10 backdrop-blur rounded-lg p-3">
            <p className="text-xs text-white/70 mb-1">Bienvenida</p>
            <p className="text-sm">
              {localConfig.welcomeMessage.replace('{businessName}', business.name)}
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-lg p-3">
            <p className="text-xs text-white/70 mb-1">Sello añadido</p>
            <p className="text-sm">
              {localConfig.stampAddedMessage
                .replace('{currentStamps}', '5')
                .replace('{requiredStamps}', '10')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
