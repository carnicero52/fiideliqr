import { useState } from 'react';
import {
  Plus,
  Eye,
  Edit2,
  Trash2,
  X,
  Gift,
  Calendar,
  Hash,
  Upload,
  Link,
} from 'lucide-react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';
import type { Reward } from '@/types';

export function Rewards() {
  const [modalState, setModalState] = useState<
    | { type: null }
    | { type: 'add' }
    | { type: 'edit'; reward: Reward }
    | { type: 'preview'; reward: Reward }
  >({ type: null });

  const { rewards, deleteReward, showConfirm, showToast } = useStore();

  const handleDelete = (reward: Reward) => {
    showConfirm({
      title: 'Eliminar Recompensa',
      message: `¿Estás seguro de eliminar "${reward.name}"? Esta acción no se puede deshacer.`,
      type: 'danger',
      onConfirm: () => {
        deleteReward(reward.id);
        showToast('Recompensa eliminada', 'success');
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Recompensas</h2>
        <button
          onClick={() => setModalState({ type: 'add' })}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          Nueva Recompensa
        </button>
      </div>

      {/* Rewards Grid */}
      {rewards.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700">
          <Gift className="w-16 h-16 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No hay recompensas
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            Crea tu primera recompensa para motivar a tus clientes
          </p>
          <button
            onClick={() => setModalState({ type: 'add' })}
            className="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-colors"
          >
            Crear Recompensa
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rewards.map((reward) => (
            <div
              key={reward.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden hover:shadow-md transition-shadow"
            >
              {/* Image */}
              <div className="h-40 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 flex items-center justify-center relative">
                {reward.imageUrl ? (
                  <img
                    src={reward.imageUrl}
                    alt={reward.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Gift className="w-16 h-16 text-gray-300 dark:text-gray-600" />
                )}
                <div className="absolute top-3 right-3 flex gap-1">
                  <span
                    className={cn(
                      'px-2 py-1 rounded-full text-xs font-medium',
                      reward.isActive
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                    )}
                  >
                    {reward.isActive ? 'Activa' : 'Inactiva'}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900 dark:text-white">{reward.name}</h3>
                  <span className="px-2 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-xs font-medium">
                    {reward.requiredStamps} sellos
                  </span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 mb-3">
                  {reward.description}
                </p>
                <div className="flex items-center gap-2 text-xs text-gray-400 dark:text-gray-500 mb-4">
                  <Hash className="w-3 h-3" />
                  <span>{reward.promoCode}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setModalState({ type: 'preview', reward })}
                    className="flex-1 py-2 px-3 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-center gap-1"
                  >
                    <Eye className="w-4 h-4" />
                    Preview
                  </button>
                  <button
                    onClick={() => setModalState({ type: 'edit', reward })}
                    className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(reward)}
                    className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      {modalState.type === 'add' && <RewardModal onClose={() => setModalState({ type: null })} />}
      {modalState.type === 'edit' && (
        <RewardModal reward={modalState.reward} onClose={() => setModalState({ type: null })} />
      )}
      {modalState.type === 'preview' && (
        <PreviewModal reward={modalState.reward} onClose={() => setModalState({ type: null })} />
      )}
    </div>
  );
}

interface RewardModalProps {
  reward?: Reward;
  onClose: () => void;
}

function RewardModal({ reward, onClose }: RewardModalProps) {
  const isEditing = !!reward;
  const { addReward, updateReward, business } = useStore();

  const [formData, setFormData] = useState({
    name: reward?.name || '',
    description: reward?.description || '',
    requiredStamps: reward?.requiredStamps || 10,
    isActive: reward?.isActive ?? true,
    imageUrl: reward?.imageUrl || '',
    validFrom: reward?.validFrom || new Date().toISOString().split('T')[0],
    validUntil: reward?.validUntil || '2025-12-31',
    promoCode: reward?.promoCode || `PROMO${Math.floor(Math.random() * 10000)}`,
  });

  const [imageInputType, setImageInputType] = useState<'upload' | 'url'>(
    reward?.imageUrl?.startsWith('http') ? 'url' : 'upload'
  );

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('La imagen debe ser menor a 2MB');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData({ ...formData, imageUrl: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isEditing) {
      updateReward(reward.id, formData);
    } else {
      addReward({
        ...formData,
        businessId: business.id,
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {isEditing ? 'Editar Recompensa' : 'Nueva Recompensa'}
            </h3>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nombre
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ej: Café Gratis"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Descripción
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe la recompensa..."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Sellos requeridos
              </label>
              <input
                type="number"
                min={1}
                max={100}
                value={formData.requiredStamps}
                onChange={(e) =>
                  setFormData({ ...formData, requiredStamps: parseInt(e.target.value) || 1 })
                }
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Imagen
              </label>
              <div className="flex gap-2 mb-3">
                <button
                  type="button"
                  onClick={() => setImageInputType('upload')}
                  className={cn(
                    'flex-1 py-2 px-3 rounded-lg border transition-colors flex items-center justify-center gap-2',
                    imageInputType === 'upload'
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600'
                      : 'border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300'
                  )}
                >
                  <Upload className="w-4 h-4" />
                  Subir
                </button>
                <button
                  type="button"
                  onClick={() => setImageInputType('url')}
                  className={cn(
                    'flex-1 py-2 px-3 rounded-lg border transition-colors flex items-center justify-center gap-2',
                    imageInputType === 'url'
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600'
                      : 'border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300'
                  )}
                >
                  <Link className="w-4 h-4" />
                  URL
                </button>
              </div>

              {imageInputType === 'upload' ? (
                <div className="relative">
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/gif,image/webp"
                    onChange={handleImageUpload}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-indigo-50 file:text-indigo-600"
                  />
                  <p className="text-xs text-gray-500 mt-1">Máximo 2MB (PNG, JPG, GIF, WebP)</p>
                </div>
              ) : (
                <input
                  type="url"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                  placeholder="https://ejemplo.com/imagen.jpg"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
              )}

              {formData.imageUrl && (
                <div className="mt-3 p-2 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <img
                    src={formData.imageUrl}
                    alt="Preview"
                    className="w-full h-32 object-cover rounded"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '';
                    }}
                  />
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  <Calendar className="w-4 h-4 inline mr-1" />
                  Válido desde
                </label>
                <input
                  type="date"
                  value={formData.validFrom}
                  onChange={(e) => setFormData({ ...formData, validFrom: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  <Calendar className="w-4 h-4 inline mr-1" />
                  Válido hasta
                </label>
                <input
                  type="date"
                  value={formData.validUntil}
                  onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                <Hash className="w-4 h-4 inline mr-1" />
                Código promocional
              </label>
              <input
                type="text"
                value={formData.promoCode}
                onChange={(e) => setFormData({ ...formData, promoCode: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white font-mono"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isActive"
                checked={formData.isActive}
                onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                className="w-4 h-4 text-indigo-500 rounded"
              />
              <label htmlFor="isActive" className="text-sm text-gray-700 dark:text-gray-300">
                Recompensa activa
              </label>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2 px-4 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg"
              >
                {isEditing ? 'Guardar Cambios' : 'Crear Recompensa'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

function PreviewModal({ reward, onClose }: { reward: Reward; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-sm w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Vista Previa</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4">
          {/* Card Preview */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div className="h-32 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 flex items-center justify-center">
              {reward.imageUrl ? (
                <img
                  src={reward.imageUrl}
                  alt={reward.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Gift className="w-12 h-12 text-gray-300 dark:text-gray-600" />
              )}
            </div>
            <div className="p-4">
              <h4 className="font-semibold text-gray-900 dark:text-white">{reward.name}</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{reward.description}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="px-2 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-xs font-medium">
                  {reward.requiredStamps} sellos
                </span>
                <span className="text-xs text-gray-400">{reward.promoCode}</span>
              </div>
            </div>
          </div>

          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-4">
            Así verán los clientes esta recompensa
          </p>
        </div>
      </div>
    </div>
  );
}
