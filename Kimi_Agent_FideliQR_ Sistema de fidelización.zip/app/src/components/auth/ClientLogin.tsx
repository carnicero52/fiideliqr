import { useState } from 'react';
import { QrCode, Phone, User, ArrowLeft, Store } from 'lucide-react';
import { useStore } from '@/store';
import { cn } from '@/utils/cn';

export function ClientLogin() {
  const [step, setStep] = useState<'phone' | 'register'>('phone');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { business, loginClient, setCurrentPanel, customers, showToast } = useStore();

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    await new Promise((resolve) => setTimeout(resolve, 300));

    const fullPhone = `${business.phonePrefix} ${phone}`;
    const existingCustomer = customers.find((c) => c.phone === fullPhone);

    if (existingCustomer) {
      loginClient(fullPhone);
      showToast(`¡Bienvenido de vuelta, ${existingCustomer.name}!`, 'success');
    } else {
      setStep('register');
    }
    setIsLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 300));

    const fullPhone = `${business.phonePrefix} ${phone}`;
    const success = loginClient(fullPhone, name.trim());

    if (success) {
      showToast('¡Registro exitoso! Bienvenido a ' + business.name, 'success');
    }
    setIsLoading(false);
  };

  const handleBack = () => {
    setStep('phone');
    setName('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 via-purple-500 to-violet-600 p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-2xl shadow-2xl overflow-hidden">
        <div className="p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl mb-4">
              <QrCode className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">FideliQR</h1>
            <div className="flex items-center justify-center gap-2 mt-2">
              <Store className="w-4 h-4 text-gray-400" />
              <p className="text-gray-500 dark:text-gray-400">{business.name}</p>
            </div>
          </div>

          {step === 'phone' ? (
            <>
              <div className="text-center mb-6">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Accede a tu tarjeta de fidelidad
                </h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Ingresa tu número de teléfono para continuar
                </p>
              </div>

              <form onSubmit={handlePhoneSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Número de teléfono
                  </label>
                  <div className="flex gap-2">
                    <div className="flex-shrink-0 px-3 py-3 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 font-medium">
                      {business.phonePrefix}
                    </div>
                    <div className="relative flex-1">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                        placeholder="4121234567"
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all"
                        required
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || phone.length < 7}
                  className={cn(
                    'w-full py-3 px-4 bg-gradient-to-r from-indigo-500 to-violet-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed',
                    isLoading && 'animate-pulse'
                  )}
                >
                  {isLoading ? 'Verificando...' : 'Continuar'}
                </button>
              </form>
            </>
          ) : (
            <>
              <div className="text-center mb-6">
                <button
                  onClick={handleBack}
                  className="inline-flex items-center gap-1 text-sm text-indigo-600 dark:text-indigo-400 hover:underline mb-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Volver
                </button>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Completa tu registro
                </h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  {business.phonePrefix} {phone}
                </p>
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tu nombre
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ej: María González"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !name.trim()}
                  className={cn(
                    'w-full py-3 px-4 bg-gradient-to-r from-indigo-500 to-violet-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed',
                    isLoading && 'animate-pulse'
                  )}
                >
                  {isLoading ? 'Registrando...' : 'Registrarme y obtener mi QR'}
                </button>
              </form>
            </>
          )}

          {/* Switch to Admin */}
          <div className="mt-6 text-center">
            <button
              onClick={() => setCurrentPanel('admin')}
              className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              ¿Eres administrador? Accede aquí
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
