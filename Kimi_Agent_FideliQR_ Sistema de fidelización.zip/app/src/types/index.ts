// Tipos de datos para FideliQR

export interface Business {
  id: string;
  name: string;
  logoUrl: string;
  primaryColor: string;
  secondaryColor: string;
  description: string;
  address: string;
  phone: string;
  email: string;
  phonePrefix: string;
}

export interface AdminUser {
  id: string;
  businessId: string;
  email: string;
  name: string;
  role: 'admin' | 'employee';
  authProvider: 'google' | 'email';
  avatarUrl?: string;
}

export interface Customer {
  id: string;
  businessId: string;
  phone: string;
  name: string;
  email: string;
  qrCode: string;
  totalStamps: number;
  redeemedRewards: number;
  createdAt: string;
  lastVisit: string;
  isActive: boolean;
  avatarUrl?: string;
}

export interface Stamp {
  id: string;
  customerId: string;
  businessId: string;
  source: 'scan' | 'manual';
  createdAt: string;
  notes?: string;
}

export interface Reward {
  id: string;
  businessId: string;
  name: string;
  description: string;
  requiredStamps: number;
  isActive: boolean;
  imageUrl: string;
  validFrom: string;
  validUntil: string;
  promoCode: string;
}

export interface Redemption {
  id: string;
  customerId: string;
  rewardId: string;
  usedAt: string;
  code: string;
}

export interface LoyaltyConfig {
  programName: string;
  stampsForReward: number;
  stampType: 'visits' | 'purchases' | 'points';
  stampExpiration: number | null;
}

export interface NotificationConfig {
  welcomeMessage: string;
  stampAddedMessage: string;
  nearRewardMessage: string;
  rewardEarnedMessage: string;
  promoMessage: string;
  pushEnabled: boolean;
  smsEnabled: boolean;
  emailEnabled: boolean;
}

export interface ActionLog {
  id: string;
  action: string;
  details: string;
  performedBy: string;
  timestamp: string;
  type: 'info' | 'warning' | 'danger';
}

export type AdminSection = 'dashboard' | 'customers' | 'rewards' | 'notifications' | 'settings' | 'help';
export type SettingsTab = 'business' | 'loyalty' | 'rewards' | 'notifications' | 'customers' | 'danger';
export type CurrentPanel = 'admin' | 'client';

export interface ConfirmModalConfig {
  title: string;
  message: string;
  type: 'warning' | 'danger' | 'info';
  requireTyping?: string;
  requirePassword?: boolean;
  onConfirm: () => void;
}

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}
